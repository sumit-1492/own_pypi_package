import setuptools 
setuptools.setup( 
    name='dataprocessingml', 
    version='0.1', 
    author="Sumit Kumar sahoo", 
    author_email="sumitlala99@gmail.com", 
    description="Basic Machine Learing data processing", 
    packages=setuptools.find_packages(), 
    classifiers=[ "Programming Language :: Python :: 3", 
    "License :: OSI Approved :: MIT License", 
    "Operating System :: OS Independent", 
    ], 
    )